# AutoFarm (Fabric 1.21.4, client-side)

G = aç/kapat, R + G = menü, `/autofarm gui`, `/autofarm mode 1-4`, `/autofarm speed 1-15`

Modlar: 1 Kır, 2 Ek, 3 Kır + Ek, 4 Kemik tozu (baktığın blok: ek + kemik tozu + kır).
Mod 4 için hotbarda çapa, kemik tozu ve ekin (havuç vs.) olmalı.

Derleme: GitHub Actions -> Actions sekmesi -> son çalışma -> Artifacts -> AutoFarm-jar.
